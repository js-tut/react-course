import React, { Component } from "react";

export default class TodoInput extends Component {
  render() {
    return <h1>hello from todo input</h1>;
  }
}
