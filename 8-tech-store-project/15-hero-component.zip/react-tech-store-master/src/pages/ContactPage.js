import React from "react";

export default function ContactPage() {
  return (
    <>
      <h1>Hello From Contact Page</h1>
    </>
  );
}
