import React from "react";

export default function CartPage() {
  return (
    <>
      <h1>Hello From Cart Page</h1>
    </>
  );
}
