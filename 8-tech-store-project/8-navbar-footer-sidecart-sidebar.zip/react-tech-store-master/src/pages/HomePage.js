import React from "react";

export default function HomePage() {
  return (
    <>
      <h1>Hello From Home Page</h1>
    </>
  );
}
