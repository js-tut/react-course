import React from "react";

export default function CartTotals() {
  return <div>CartTotals</div>;
}
