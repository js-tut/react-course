export const linkData = [
  {
    id: 1,
    text: "home",
    path: "/"
  },
  {
    id: 2,
    text: "about",
    path: "/about"
  },
  {
    id: 3,
    text: "products",
    path: "/product"
  },
  {
    id: 4,
    text: "contact",
    path: "/contact"
  },
  {
    id: 5,
    text: "cart",
    path: "/cart"
  }
];
