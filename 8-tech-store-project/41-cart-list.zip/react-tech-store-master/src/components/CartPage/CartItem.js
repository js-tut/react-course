import React from "react";

export default function CartItem() {
  return <div>CartItem</div>;
}
