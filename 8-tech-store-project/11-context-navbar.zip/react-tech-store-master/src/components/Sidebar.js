import React from "react";

export default function Sidebar() {
  return <div>hello from sidebar</div>;
}
