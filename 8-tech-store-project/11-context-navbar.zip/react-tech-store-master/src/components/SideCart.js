import React from "react";

export default function SideCart() {
  return <div>hello from sidecart</div>;
}
