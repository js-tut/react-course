import React from "react";

export default function AboutPage() {
  return (
    <>
      <h1>Hello From About Page</h1>
    </>
  );
}
