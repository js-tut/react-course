import React from "react";
import CartItem from "./CartItem";
export default function CartList() {
  return (
    <div>
      CartList
      <CartItem />
    </div>
  );
}
