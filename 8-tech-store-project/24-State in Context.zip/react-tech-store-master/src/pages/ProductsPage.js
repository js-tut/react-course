import React from "react";

export default function ProductsPage() {
  return (
    <>
      <h1>Hello From Products Page</h1>
    </>
  );
}
