import React from "react";

export default function CartColumns() {
  return <div>CartColumns</div>;
}
