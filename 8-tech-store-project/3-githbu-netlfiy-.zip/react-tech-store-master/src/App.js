import React, { Component } from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
class App extends Component {
  render() {
    return <h1>hello from tech store</h1>;
  }
}

export default App;
