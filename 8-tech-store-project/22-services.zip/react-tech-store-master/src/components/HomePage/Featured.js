import React from "react";

export default function Featured() {
  return <div>Hello From Featured</div>;
}
