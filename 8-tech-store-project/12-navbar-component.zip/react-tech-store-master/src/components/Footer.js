import React from "react";

export default function Footer() {
  return <>hello from footer</>;
}
