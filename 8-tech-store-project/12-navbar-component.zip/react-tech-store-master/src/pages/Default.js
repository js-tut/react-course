import React from "react";

export default function Default() {
  return (
    <>
      <h1>Hello From Default Page</h1>
    </>
  );
}
