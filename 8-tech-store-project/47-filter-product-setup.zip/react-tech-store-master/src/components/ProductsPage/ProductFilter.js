import React from "react";

export default function ProductFilter() {
  return <div>Filtering Component</div>;
}
