import React from "react";

export default function SingleProductPage() {
  return (
    <>
      <h1>Hello From SingleProduct Page</h1>
    </>
  );
}
