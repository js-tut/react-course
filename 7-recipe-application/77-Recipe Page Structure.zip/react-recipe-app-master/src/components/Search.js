import React, { Component } from "react";

export default class Search extends Component {
  render() {
    return <div>Hello From Search</div>;
  }
}
