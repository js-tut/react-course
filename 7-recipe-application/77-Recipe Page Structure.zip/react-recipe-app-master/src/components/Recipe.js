import React, { Component } from "react";

export default class Recipe extends Component {
  render() {
    return <div>hello from recipe</div>;
  }
}
