import React, { Component } from "react";
import Recipe from "./Recipe";
export default class RecipeList extends Component {
  render() {
    return (
      <div>
        Hello From recipe list
        <Recipe />
      </div>
    );
  }
}
