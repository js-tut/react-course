import React, { Component } from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
class App extends Component {
  render() {
    return <div>hello from our recipe app</div>;
  }
}

export default App;
