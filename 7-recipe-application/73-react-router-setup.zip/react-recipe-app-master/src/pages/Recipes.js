import React, { Component } from "react";

export default class Recipes extends Component {
  render() {
    return <h4>Hello From Recipes Page</h4>;
  }
}
