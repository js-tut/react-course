import React, { Component } from "react";

export default class Home extends Component {
  render() {
    return <h4>Hello From Home Page</h4>;
  }
}
