import React, { Component } from "react";

export default class Default extends Component {
  render() {
    return <h4>Hello From ErrorPage</h4>;
  }
}
