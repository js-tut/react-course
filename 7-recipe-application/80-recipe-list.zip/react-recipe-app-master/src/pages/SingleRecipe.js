import React, { Component } from "react";

export default class SingleRecipe extends Component {
  render() {
    return <h4>Hello From Single Recipe Page</h4>;
  }
}
