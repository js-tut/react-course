const books = [
  { id: 1, book: "book number one", author: "john doe" },
  {
    id: 2,
    book: "book number two",
    author: "bobby doe"
  },
  {
    id: 3,
    book: "book number two",
    author: "bobby doe"
  },
  {
    id: 4,
    book: "book number two",
    author: "bobby doe"
  },
  {
    id: 5,
    book: "book number two",
    author: "bobby doe"
  }
];

export default books;
