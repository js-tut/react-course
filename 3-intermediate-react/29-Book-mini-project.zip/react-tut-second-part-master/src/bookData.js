const books = [
  {
    id: 1,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/91ILDdvFJ4L._AC_UL200_SR200,200_.jpg",
    title:
      "Girl, Stop Apologizing: A Shame-Free Plan for Embracing and Achieving Your Goals",
    author: "Rachel Hollis"
  },
  {
    id: 2,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/81WWiiLgEyL._AC_UL200_SR200,200_.jpg",
    title: "Where the Crawdads Sing",
    author: "Delia Owens"
  },
  {
    id: 3,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/81h2gWPTYJL._AC_UL200_SR200,200_.jpg",
    title: "Becoming",
    author: "Michelle Obama"
  },
  {
    id: 4,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/81h2gWPTYJL._AC_UL200_SR200,200_.jpg",
    title: "Becoming",
    author: "Michelle Obama"
  },
  {
    id: 5,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/81h2gWPTYJL._AC_UL200_SR200,200_.jpg",
    title: "Becoming",
    author: "Michelle Obama"
  },
  {
    id: 6,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/81h2gWPTYJL._AC_UL200_SR200,200_.jpg",
    title: "Becoming",
    author: "Michelle Obama"
  }
];

export default books;
