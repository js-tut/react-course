import React, { Component } from "react";
import Tour from "../Tour";
export default class TourList extends Component {
  render() {
    return (
      <div>
        Hello From Tourslist
        <Tour />
      </div>
    );
  }
}
