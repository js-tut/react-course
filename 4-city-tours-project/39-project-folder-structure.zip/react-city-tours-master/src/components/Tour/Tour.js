import React, { Component } from "react";

export default class Tour extends Component {
  render() {
    return <h1>Hello from tour</h1>;
  }
}
